Evidências do projeto BarberBook

Conteúdo:
- api_root.txt: resposta do endpoint GET /api
- check_email.txt: resposta do endpoint GET /api/auth/check-email?email=teste@example.com
- git_log.txt: últimos commits (se o repositório for público/local)
- schema.prisma: trecho do schema do Prisma
- migrations/: migrations do banco (lista parcial)

Observações:
- O backend está rodando em http://localhost:3000
- A autenticação JWT foi movida para cookie HttpOnly no backend (ver backend/src/auth/auth.controller.ts)
- Para reproduzir localmente:
  1. cd backend
  2. npm install
  3. npm run start:dev

Gerado automaticamente pelo assistente para envio ao professor.
